
# -*- coding:utf8 -*-

# 新手引导
from time import sleep
import os
import unittest2
from appium.webdriver.common.touch_action import TouchAction
from config import ANDROID_DRIVER


class LunarTest_guidance(unittest2.TestCase):

    def setUp(self):
        self.driver = ANDROID_DRIVER
        sleep(1)

    def test_can_help(self):
        # 经期模式
        driver = self.driver
        # TrackMyCycle = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a6n")
        # TrackMyCycle.click()
        driver.find_element_by_xpath("//*[@text='Track My Cycle']").click()
        sleep(0.5)

        # NextClick = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/ds")
        # NextClick.click()
        driver.find_element_by_xpath("//*[@text='Next']").click()
        sleep(0.5)

        TouchAction(driver).tap(x=953, y=618).perform()
        sleep(0.5)

        # 判断是否正确关闭新手引导
        self.assertEqual(driver.current_activity, '.activity.MainLunarActivity')

        sleep(3)

    def tearDown(self):
        self.driver.quit()
        # 清除缓存
        os.system('adb shell pm clear com.period.calendar.ovulation.tracker.lunar')

if __name__ == '__main__':
    unittest2.main(verbosity=2)
    # testunit = unittest2.TestSuite()
    # # testunit.addTest(LunarTest('test_can_help'))
    # testunit.addTest(LunarTest('test_can_help'))
    # fp = open('./testReport_noviceGuidance.html', 'wb')
    # runner = HTMLTestRunner.HTMLTestRunner(stream=fp,
    #                                        title='lunar Android Test Novice Guidance')
    # runner.run(testunit)
    # fp.close()


# adb shell pm clear $packagename