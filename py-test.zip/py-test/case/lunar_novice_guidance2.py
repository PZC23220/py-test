
# -*- coding:utf8 -*-

# 新手引导
from time import sleep
import os
import unittest2
from appium import webdriver

class LunarTest_guidance2(unittest2.TestCase):

    def setUp(self):
        ANDROID_BASE_CAPS = {
            'appPackage': 'com.period.calendar.ovulation.tracker.lunar',
            'automationName': 'Appium',
            'platformName': 'Android',
            'platformVersion': '9',
            'deviceName': 'HJS0219225003593',
            'noReset': True,
            'appActivity': '.activity.MainLunarActivity',
        }

        ANDROID_DRIVER = webdriver.Remote('http://localhost:4723/wd/hub', ANDROID_BASE_CAPS)
        self.driver = ANDROID_DRIVER
        sleep(1)


    def test_can_help2(self):
        # 备孕模式
        driver = self.driver
        driver.find_element_by_xpath("//*[@text='Help Me Conceive']").click()
        sleep(0.5)

        NextClick = driver.find_element_by_xpath("//*[@text='Next']")
        NextClick.click()
        sleep(0.5)

        NextClick.click()
        sleep(0.5)

        driver.find_element_by_xpath("//*[@text='Next']").click()
        sleep(0.5)

        driver.find_element_by_xpath("//*[@text='Finish']").click()
        sleep(0.5)
        self.assertEqual(driver.current_activity, '.activity.MainLunarActivity')
        sleep(1)

    def tearDown(self):
        self.driver.quit()
        os.system('adb shell pm clear com.period.calendar.ovulation.tracker.lunar')


if __name__ == '__main__':
    unittest2.main(verbosity=2)
    # testunit = unittest2.TestSuite()
    # # testunit.addTest(LunarTest('test_can_help'))
    # testunit.addTest(LunarTest('test_can_help2'))
    # fp = open('./testReport_noviceGuidance.html', 'wb')
    # runner = HTMLTestRunner.HTMLTestRunner(stream=fp,
    #                                        title='lunar Android Test Novice Guidance')
    # runner.run(testunit)
    # fp.close()


# adb shell pm clear $packagename