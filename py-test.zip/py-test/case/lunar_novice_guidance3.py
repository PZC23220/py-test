
# -*- coding:utf8 -*-

# 新手引导

from time import sleep
import unittest2
from appium import webdriver


class LunarTest_guidance3(unittest2.TestCase):

    def setUp(self):
        ANDROID_BASE_CAPS = {
            'appPackage': 'com.period.calendar.ovulation.tracker.lunar',
            'automationName': 'Appium',
            'platformName': 'Android',
            'platformVersion': '9',
            'deviceName': 'HJS0219225003593',
            'noReset': True,
            'appActivity': '.activity.MainLunarActivity',
        }

        ANDROID_DRIVER = webdriver.Remote('http://localhost:4723/wd/hub', ANDROID_BASE_CAPS)
        self.driver = ANDROID_DRIVER
        sleep(1)

    def test_can_help3(self):
        # 经期模式
        driver = self.driver
        # TrackMyCycle = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a6n")
        # TrackMyCycle.click()
        driver.find_element_by_xpath("//*[@text='Track My Cycle']").click()
        sleep(0.5)

        NextClick = driver.find_element_by_xpath("//*[@text='Next']")
        NextClick.click()
        sleep(0.5)

        NextClick.click()
        sleep(0.5)

        driver.find_element_by_xpath("//*[@text='Next']").click()
        sleep(0.5)

        driver.find_element_by_xpath("//*[@text='I Don’t Use It']").click()
        sleep(0.5)

        driver.find_element_by_xpath("//*[@text='Finish']").click()
        sleep(0.5)

        # Skip = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/kz")
        # Skip.click()

        # 判断是否正确关闭新手引导
        self.assertEqual(driver.current_activity, '.activity.MainLunarActivity')

        sleep(1)

    def tearDown(self):
        self.driver.quit()


if __name__ == '__main__':
    unittest2.main(verbosity=2)
    # testunit = unittest2.TestSuite()
    # # testunit.addTest(LunarTest('test_can_help'))
    # testunit.addTest(LunarTest('test_can_help'))
    # fp = open('./testReport_noviceGuidance.html', 'wb')
    # runner = HTMLTestRunner.HTMLTestRunner(stream=fp,
    #                                        title='lunar Android Test Novice Guidance')
    # runner.run(testunit)
    # fp.close()


# adb shell pm clear $packagename