# coding:utf-8
import unittest2
import os
import HTMLTestRunner
import time

# 用例路径
case_path = os.path.join(os.getcwd(), "case")
# case_path = './case'

# 获取所有测试用例
def get_allcase():
    discover = unittest2.defaultTestLoader.discover(case_path,
                                                    pattern="*.py")
    suite = unittest2.TestSuite()
    suite.addTest(discover)
    return suite

if __name__ == "__main__":
    # timestr = time.strftime("%Y_%m_%d_%H_%M", time.localtime())
    # filename = './report/test_Lunar_' + timestr + '.html'
    # fp = open(filename, 'wb')
    fp = open('./report/test_Lunar.html', 'wb')
    runner = HTMLTestRunner.HTMLTestRunner(stream=fp,
                                           title='lunar Android Test')
    # 运行测试用例
    # runner = unittest2.TextTestRunner()
    runner.run(get_allcase())
    fp.close()
