# -*- coding:utf8 -*-

from appium import webdriver
from time import sleep

ANDROID_BASE_CAPS = {
    'appPackage': 'com.period.calendar.ovulation.tracker.lunar',
    'automationName': 'Appium',
    'platformName': 'Android',
    'platformVersion': '9',
    'deviceName': '988e94433452323231',
    'noReset': True,
    'appActivity': '.activity.MainLunarActivity',
}

ANDROID_DRIVER = webdriver.Remote('http://localhost:4723/wd/hub', ANDROID_BASE_CAPS)

# 开启权限
def ALLOW_CLICK(driver):
    try:
        Allow = driver.find_element_by_id("com.android.packageinstaller:id/permission_allow_button")
        Allow.click()
        sleep(0.5)
    except:
        pass

def LOGIN(driver):
    # login google
    Login_Google = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/de")
    Login_Google.click()
    sleep(2)
    try:
        Account = driver.find_element_by_id("com.google.android.gms:id/account_name")
        Account.click()
    except:
        pass
    sleep(3)
