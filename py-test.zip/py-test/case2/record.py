
# -*- coding:utf8 -*-

# 新手引导
from time import sleep
import unittest2
from appium.webdriver.common.touch_action import TouchAction

from config import ANDROID_DRIVER

class LunarTest_record(unittest2.TestCase):

    @classmethod
    def setUpClass(self):
        self.driver = ANDROID_DRIVER
        print("record start!")
        # sleep(1)

    def test_record(self):
        driver = self.driver
        driver.tap([(72, 2126), (143, 2163)], 200)
        sleep(0.5)

        # 点击log
        # Log = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/sz")
        # Log.click()
        driver.tap([(873,832), (993,952)], 200)
        sleep(0.5)

        try:
            Next = driver.find_element_by_xpath("//*[@text='Next']")
            Next.click()
            Next.click()
            Next.click()
            driver.tap([(165,1440), (915,1584)], 200)
            driver.find_element_by_xpath("//*[@text='Finish']").click()
            driver.tap([(873, 832), (993, 952)], 200)
            sleep(0.5)
        except:
            pass

        try:
            # update my log
            # driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/ds").click()
            driver.tap([(323,1242), (756,1314)], 200)
            sleep(0.5)
        except:
            print("No Log")
            pass

        # 设置record
        # 滑动 how are you feeling?
        # TouchAction(driver).press(x=875, y=456).move_to(x=400, y=454).release().perform()

        # 点击describe your sexual activity ——None
        driver.tap([(776,874), (932,1030)], 200)
        try:
            # Analyze = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a2w")
            # Analyze.click()
            driver.find_element_by_xpath("//*[@text='ANALYZE']").click()
            sleep(3)
            TouchAction(driver).tap(x=60, y=147).perform()
        except:
            TouchAction(driver).tap(x=67, y=151).perform()

        # try:

        self.assertEqual(driver.current_activity, '.activity.MainLunarActivity')
        sleep(2)

    @classmethod
    def tearDownClass(self):
        # self.driver.quit()
        print("record end!")

if __name__ == '__main__':
    unittest2.main(verbosity=2)
