
# -*- coding:utf8 -*-

# 新手引导
from time import sleep
import unittest2
from appium.webdriver.common.touch_action import TouchAction

from config import ANDROID_DRIVER

class LunarTest_today(unittest2.TestCase):

    @classmethod
    def setUpClass(self):
        self.driver = ANDROID_DRIVER
        # sleep(1)
        print('today start!')

    def test_today(self):
        driver = self.driver
        driver.tap([(72, 2126), (143, 2163)], 200)

        # 首页Period Started/Period Ended
        try:
            # PeriodStarted = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/em")
            # PeriodStarted.click()
            TouchAction(driver).tap(x=447, y=569).perform()
            sleep(0.5)
            TouchAction(driver).tap(x=451, y=1058).perform()
            sleep(0.5)
        except:
            print("In Period")
            pass

        # 点击经期球
        # Circle = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/e7")
        # Circle.click()
        TouchAction(driver).tap(x=785, y=439).perform()
        sleep(0.5)

        # Start = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a69")
        # Start.click()
        TouchAction(driver).tap(x=615, y=1732).perform()
        sleep(0.5)

        driver.tap([(72,2126), (143,2163)], 200)
        sleep(0.5)

        # 点击log
        # Log = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/sz")
        # Log.click()
        TouchAction(driver).tap(x=930, y=884).perform()
        sleep(0.5)

        try:
            # update my log
            # driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/ds").click()
            TouchAction(driver).tap(x=536, y=1596).perform()
            sleep(0.5)
        except:
            print("No Log")
            pass

        # 设置record
        # 滑动 how are you feeling?
        TouchAction(driver).press(x=875, y=456).move_to(x=400, y=454).release().perform()
        sleep(0.5)

        driver.tap([(660,771), (793,904)], 200)
        sleep(0.5)

        TouchAction(driver).tap(x=67, y=151).perform()

        sleep(3)

        TouchAction(driver).tap(x=60, y=147).perform()
        self.assertEqual(driver.current_activity, '.activity.MainLunarActivity')

        sleep(3)

    @classmethod
    def tearDownClass(self):
        self.driver.quit()
        print("today end!")


if __name__ == '__main__':
    unittest2.main(verbosity=2)
