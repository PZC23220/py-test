
# -*- coding:utf8 -*-

# 新手引导
from time import sleep
import unittest2
from appium.webdriver.common.touch_action import TouchAction

from config import ANDROID_DRIVER, LOGIN

class LunarTest_me(unittest2.TestCase):

    @classmethod
    def setUpClass(self):
        self.driver = ANDROID_DRIVER
        sleep(2)
        print('Me start!')

    def test_me(self):
        driver = self.driver
        driver.tap([(903,2034), (987,2118)], 200)
        sleep(0.5)

        # driver.refresh()
        # sleep(1)

        driver.swipe(475, 525, 490, 1603, 500)
        sleep(2)

        try:
            # 未登录
            # login
            # Login = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a3a")
            # Login.click()
            driver.find_element_by_xpath("//*[@text='Log in']").click()
            sleep(0.5)

            # google 登录
            LOGIN(driver)
        except:
            pass

        # 点击follower
        # Follower = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a4p")
        # Follower.click()
        driver.find_element_by_xpath("//*[@text='Follower']").click()
        sleep(0.5)

        self.assertEqual(driver.current_activity, 'ehab.aeia.jefaahcdia')

        driver.back()
        sleep(0.5)

        driver.find_element_by_xpath("//*[@text='Following']").click()
        sleep(0.5)

        self.assertEqual(driver.current_activity, 'ehab.aeia.abcebahfeb')

        driver.back()
        sleep(0.5)

        # setting
        # Setting = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/r2")
        # Setting.click()
        driver.tap([(0,72), (168,240)], 200)
        sleep(0.5)
        # 已登录
        # 个人资料编辑
        # Setting_List = driver.find_elements_by_id("com.period.calendar.ovulation.tracker.lunar:id/rx")
        # Setting_List[2].click()
        driver.find_element_by_xpath("//*[@text='Edit Profile']").click()
        sleep(0.5)

        # 替换头像
        # Photo = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/hl")
        # Photo.click()
        # driver.find_element_by_xpath("//*[@text='Profile Photo']").click()
        # sleep(0.5)
        # try:
        #     Allow = driver.find_element_by_id("com.android.packageinstaller:id/permission_allow_button")
        #     Allow.click()
        #     sleep(0.5)
        # except:
        #     pass

        # 选择照片
        # TouchAction(driver).tap(x=663, y=1683).perform()
        # sleep(0.5)

        # 点击save
        # Save = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a7e")
        # Save.click()
        # driver.find_element_by_xpath("//*[@text='SAVE']").click()
        # TouchAction(driver).tap(x=940, y=149).perform()
        # sleep(3)

        #点击 bio
        driver.find_element_by_xpath("//*[@text='Bio']").click()
        sleep(0.5)
        # 点击输入框
        TouchAction(driver).tap(x=112, y=350).perform()
        sleep(0.5)
        # Bio.send_keys("12212345678")
        TouchAction(driver).tap(x=119, y=1657).perform()
        TouchAction(driver).tap(x=333, y=1817).perform()
        TouchAction(driver).tap(x=534, y=1819).perform()
        TouchAction(driver).tap(x=987, y=1961).perform()
        sleep(0.5)

        # 保存
        # OKClick = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/qo")
        # OKClick.click()
        driver.tap([(969,120), (1041,192)], 200)
        sleep(1)

        # driver.back()
        driver.tap([(0, 72), (168, 240)], 200)
        sleep(0.5)

        # 点击logout
        driver.find_element_by_xpath("//*[@text='Logout']").click()
        sleep(0.5)

        driver.back()
        sleep(0.5)

        # login
        driver.find_element_by_xpath("//*[@text='Log in']").click()
        sleep(0.5)

        # google 登录
        LOGIN(driver)

        # 登录之后login按钮消失
        try:
            driver.find_element_by_xpath("//*[@text='Log in']").click()
            self.assertTrue(False, msg="logout failed!")
        except:
            pass


        sleep(2)

    @classmethod
    def tearDownClass(self):
        # self.driver.quit()
        print("Me end!")

if __name__ == '__main__':
    unittest2.main(verbosity=2)
