
# -*- coding:utf8 -*-

# 新手引导
from time import sleep
import unittest2
from appium.webdriver.common.touch_action import TouchAction

from config import ANDROID_DRIVER

class LunarTest_calender(unittest2.TestCase):

    @classmethod
    def setUpClass(self):
        self.driver = ANDROID_DRIVER
        sleep(1)
        print('Calender start!')

    def test_calender(self):
        driver = self.driver
        driver.tap([(363,2034), (447,2118)], 200)
        sleep(0.5)

        # TouchAction(driver).press(x=467, y=2052).move_to(x=501, y=816).release().perform()
        # sleep(0.5)

        # 点击左箭头
        # LeftArrow = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/ph")
        # LeftArrow.click()
        TouchAction(driver).tap(x=328, y=298).perform()
        sleep(0.5)

        # 点击18号 period start
        # 日历会变，所以坐标会变
        TouchAction(driver).tap(x=130, y=987).perform()
        sleep(0.5)
        # 点击start
        # Start = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a69")
        # Start.click()
        driver.find_element_by_xpath("//*[@text='Start']").click()
        sleep(0.5)

        # 点击20号 period end
        TouchAction(driver).tap(x=395, y=992).perform()
        sleep(0.5)
        # 点击end
        # End = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a44")
        # End.click()
        driver.find_element_by_xpath("//*[@text='End']").click()
        sleep(0.5)

        # 点击21号
        TouchAction(driver).tap(x=531, y=990).perform()

        # 判断是否有记录
        try:
            driver.find_element_by_xpath("//*[@text='In Period']")
            self.assertTrue(False, msg="经期没有正常结束")
        except:
            pass

        # 点击today按钮
        # Today = driver.find_element_by_id("com.period.calendar.ovulation.tracker.lunar:id/a2e")
        # Today.click()
        driver.find_element_by_xpath("//*[@text='Today']").click()
        sleep(0.5)

        # 点击右箭头
        TouchAction(driver).tap(x=743, y=295).perform()
        sleep(0.5)

        # 点击未来 16号
        TouchAction(driver).tap(x=536, y=849).perform()
        sleep(0.5)
        # 上滑
        TouchAction(driver).press(x=507, y=1728).move_to(x=613, y=811).release().perform()
        try:
            driver.find_element_by_xpath("//*[@text='You are in prediction stage, cannot record future.']")
        except:
            self.assertTrue(False, msg="点击未来日期，不是空页面")


        # 点击today按钮
        driver.find_element_by_xpath("//*[@text='Today']").click()


        # 是否有edit period
        try:
            driver.find_element_by_xpath("//*[@text='Edit Period']")
        except:
            self.assertTrue(False, msg="点击today，页面没有edit period")


        sleep(2)

    @classmethod
    def tearDownClass(self):
        # self.driver.quit()
        print("Calender end!")

if __name__ == '__main__':
    unittest2.main(verbosity=2)
